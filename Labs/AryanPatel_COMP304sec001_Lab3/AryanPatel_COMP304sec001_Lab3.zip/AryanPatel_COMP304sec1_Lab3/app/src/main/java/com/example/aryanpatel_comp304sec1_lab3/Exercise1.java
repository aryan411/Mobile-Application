package com.example.aryanpatel_comp304sec1_lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Exercise1 extends AppCompatActivity {

    private ImageView imageView;
    private AnimationDrawable frameAnimation;
    private Button start, stop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise1);
    }

    @Override
    protected void onStart(){
        super.onStart();
        loadUI();
        UIControls();
        // set background image of imageView to the AnimationDrawable
        frameAnimation = (AnimationDrawable) imageView.getBackground();
        // Stop after one iteration of animation
        frameAnimation.setOneShot(false);
    }


    private void loadUI(){
        start = (Button)findViewById(R.id.start);
        stop = (Button)findViewById(R.id.stop);
        imageView = (ImageView) findViewById(R.id.imageView);
        // Set background resource
        if (imageView != null) {
            imageView.setBackgroundResource(R.drawable.frame_animation_list);
        }
    }

    private void UIControls(){
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                frameAnimation.start();
            }
        });
        stop.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                frameAnimation.stop();
            }
        });
    }
}