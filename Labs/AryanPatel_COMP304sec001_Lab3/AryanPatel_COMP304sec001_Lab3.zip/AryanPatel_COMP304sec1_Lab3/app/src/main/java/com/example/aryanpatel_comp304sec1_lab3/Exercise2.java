package com.example.aryanpatel_comp304sec1_lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ToggleButton;

public class Exercise2 extends AppCompatActivity {

    ToggleButton start_stop2;
    ImageView rocketImageView;
    private ImageView rocketImg;
    private Animation orbit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise2);

        rocketImageView = findViewById(R.id.rocket);
        rocketImageView.setImageResource(R.drawable.rocket);

        start_stop2 = (ToggleButton) findViewById(R.id.toggleButton2);
        start_stop2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(start_stop2.isChecked()){
                    startAnimation();

                } else{
                    stopAnimation();
                }
            }
        });
    }
    private void startAnimation() {

        Animation rocketAnimation = AnimationUtils.loadAnimation(this, R.anim.rocket_animation);
        rocketAnimation.setRepeatCount(-1);
        rocketAnimation.setRepeatMode(Animation.RESTART);
        rocketImageView.startAnimation(rocketAnimation);

    }

    private void stopAnimation() {
        this.rocketImageView.clearAnimation();
    }
}