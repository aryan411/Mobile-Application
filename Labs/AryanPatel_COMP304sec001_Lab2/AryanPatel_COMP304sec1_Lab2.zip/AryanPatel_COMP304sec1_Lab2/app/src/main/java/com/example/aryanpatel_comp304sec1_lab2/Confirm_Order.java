package com.example.aryanpatel_comp304sec1_lab2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Confirm_Order extends AppCompatActivity {

    // Declare Variables
    String customerName, customerAddress, customerPhoneNo, customerEmailAddress, item1, item2, item3;
    String customerInfo = "";
    String customerOder = "";

    // UI Variables
    TextView customerDetails, orderItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_order);

        // Grab previously saved values
        Bundle extras = getIntent().getExtras();

        if (extras.containsKey("item1")) {
            item1 = extras.getString("item1");
        }
        if (extras.containsKey("item2")) {
            item2 = extras.getString("item2");
        }
        if (extras.containsKey("item3")) {
            item3 = extras.getString("item3");
        }

        if (extras.containsKey("customerName")) {
            customerName = extras.getString("customerName");
        }
        if (extras.containsKey("customerAddress")) {
            customerAddress = extras.getString("customerAddress");
        }
        if (extras.containsKey("customerPhoneNo")) {
            customerPhoneNo = extras.getString("customerPhoneNo");
        }
        if (extras.containsKey("customerEmailAddress")) {
            customerEmailAddress = extras.getString("customerEmailAddress");
        }

        if (item1 != null) {
            customerOder += item1 + "\n";
        }
        if (item2 != null) {
            customerOder += item2 + "\n";
        }
        if (item3 != null) {
            customerOder += item3;
        }

        if (customerName != null) {
            customerInfo += "Name:" + customerName + "\n";
        }
        if (customerAddress != null) {
            customerInfo += "Address:" + customerAddress + "\n";
        }
        if (customerPhoneNo != null) {
            customerInfo += "Phone Number:" + customerPhoneNo + "\n";
        }
        if (customerEmailAddress != null) {
            customerInfo += "Email Address:" + customerEmailAddress + "\n";
        }


        orderItems = (TextView) findViewById(R.id.fooditems);
        customerDetails = (TextView) findViewById(R.id.customer_info);
        customerDetails.setText(customerInfo);
        orderItems.setText(customerOder);

    }
}