package com.example.aryanpatel_comp304sec1_lab2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import android.widget.Button;
import android.widget.CheckBox;


public class Add_Food_Item extends AppCompatActivity {

    // Declare variables
    List<String> foodItemArray = new ArrayList<String>();
    String foodCategory;

    // Variables for UI
    CheckBox item1, item2, item3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_food_item);

        // select food items array depending on selected food type
        foodCategory = getIntent().getStringExtra("foodCategory");
        switch (foodCategory) {
            case "Fruits and Vegetables":
                foodItemArray = Arrays.asList(getResources().getStringArray(R.array.Food_Category_1));
                break;
            case "Grains and Cereals":
                foodItemArray = Arrays.asList(getResources().getStringArray(R.array.Food_Category_2));
                break;
            case "Dairy Foods and Beverages":
                foodItemArray = Arrays.asList(getResources().getStringArray(R.array.Food_Category_3));
                break;
            case "Meat, Sea Foods and Poultry Foods":
                foodItemArray = Arrays.asList(getResources().getStringArray(R.array.Food_Category_4));
                break;
            case "Baked Foods":
                foodItemArray = Arrays.asList(getResources().getStringArray(R.array.Food_Category_5));
                break;
            default:
                break;
        }

        // checkbox and labels
        item1 = (CheckBox) findViewById(R.id.item1);
        item2 = (CheckBox) findViewById(R.id.item2);
        item3 = (CheckBox) findViewById(R.id.item3);

        item1.setText(foodItemArray.get(0));
        item2.setText(foodItemArray.get(1));
        item3.setText(foodItemArray.get(2));
    }

    public void onClickBtnNext4(View v){
        Intent i = new Intent(Add_Food_Item.this, Order_Details.class);

        // Pass Food Category and selected Food Items
        if (item1.isChecked()){
            i.putExtra("item1", item1.getText().toString());
        } if (item2.isChecked()){
            i.putExtra("item2", item2.getText().toString());
        } if (item3.isChecked()){
            i.putExtra("item3", item3.getText().toString());
        }
        i.putExtra("foodCategory", foodCategory);

        startActivity(i);
    }
}