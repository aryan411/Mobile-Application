package com.example.aryanpatel_comp304sec1_lab2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Spinner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import android.view.View;
import android.widget.ArrayAdapter;

public class Food_Category extends AppCompatActivity {

    // variables
    List<String> foodCategoryArray = new ArrayList<String>();
    ArrayAdapter foodCategoryAdapter;
    Spinner foodCategorySpinner;
    String foodCategory;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_types);

        // spinner to select food type
        foodCategorySpinner = (Spinner)findViewById(R.id.foodCategorySpinner);
        // food types array
        foodCategoryArray = Arrays.asList(getResources().getStringArray(R.array.Fd_Type_Array));
        foodCategoryAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, foodCategoryArray);
        foodCategorySpinner.setAdapter(foodCategoryAdapter);
    }

    public void onClickBtnNext(View v){

        foodCategory = foodCategorySpinner.getSelectedItem().toString();
        Intent i = new Intent(Food_Category.this, Add_Food_Item.class);
        i.putExtra("foodCategory", foodCategory);
        startActivity(i);
    }
}