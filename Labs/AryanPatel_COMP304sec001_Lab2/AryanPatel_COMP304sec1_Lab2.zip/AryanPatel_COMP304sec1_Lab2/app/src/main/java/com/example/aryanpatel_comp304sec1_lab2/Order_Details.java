package com.example.aryanpatel_comp304sec1_lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Order_Details extends AppCompatActivity {

    // Declare variables
    String food_Item1, food_Item2, food_Item3;
    String oder_details = "";

    // UI Variables
    TextView orderItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_details);


        Bundle extras = getIntent().getExtras();
        // Grab order items
        if (extras.containsKey("item1")) {
            food_Item1 = extras.getString("item1");
        } if (extras.containsKey("item2")) {
            food_Item2 = extras.getString("item2");
        } if (extras.containsKey("item3")) {
            food_Item3 = extras.getString("item3");
        }

        orderItems = (TextView)findViewById(R.id.fooditems);
        if (food_Item1 != null){
            oder_details += food_Item1 + "\n";
        } if (food_Item2 != null){
            oder_details += food_Item2 + "\n";
        } if (food_Item3 != null){
            oder_details += food_Item3;
        }
        orderItems.setText(oder_details);
    }


    public void nextButtonClick(View v){
        Intent i = new Intent(Order_Details.this, Customer_Details.class);

        i.putExtra("item1", food_Item1);
        i.putExtra("item2", food_Item2);
        i.putExtra("item3", food_Item3);
        startActivity(i);
    }
}