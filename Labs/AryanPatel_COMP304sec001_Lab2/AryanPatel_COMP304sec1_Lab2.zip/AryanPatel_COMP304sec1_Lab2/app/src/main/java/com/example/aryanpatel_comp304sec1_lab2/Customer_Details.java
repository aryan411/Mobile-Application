package com.example.aryanpatel_comp304sec1_lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Customer_Details extends AppCompatActivity {

    // Declare Variables
    String item1, item2, item3;
    String customerOder = "";

    // UI Variables
    EditText cName, cAddress, cPhoneNo, cEmail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_details);

        // Grab previously saved values
        Bundle extras = getIntent().getExtras();
        customerOder = getIntent().getStringExtra("orderDetails");

        if (extras.containsKey("item1")) {
            item1 = extras.getString("item1");
        } if (extras.containsKey("item2")) {
            item2 = extras.getString("item2");
        } if (extras.containsKey("item3")) {
            item3 = extras.getString("item3");
        }

        // reference for all inputs
        cName = (EditText)findViewById(R.id.customer_name);
        cAddress = (EditText)findViewById(R.id.customer_address);
        cPhoneNo = (EditText)findViewById(R.id.customer_phoneno);
        cEmail = (EditText)findViewById(R.id.customer_emailaddress);
    }

    // sending all data to next activity "Confirm_Order"
    public void submitBtnClicked(View v){
        Intent i = new Intent(Customer_Details.this, Confirm_Order.class);
        i.putExtra("customerName", cName.getText().toString());
        i.putExtra("customerAddress", cAddress.getText().toString());
        i.putExtra("customerPhoneNo", cPhoneNo.getText().toString());
        i.putExtra("customerEmailAddress", cEmail.getText().toString());
        i.putExtra("customerOder", customerOder);
        i.putExtra("item1", item1);
        i.putExtra("item2", item2);
        i.putExtra("item3", item3);
        startActivity(i);
    }
}